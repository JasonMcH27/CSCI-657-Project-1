import weka.core.Instances;
import weka.core.converters.CSVLoader;
import weka.core.converters.ArffSaver;
import java.io.File;

public class CSVtoArff {
    public static void Convert(String input, String output) throws Exception {
        try {
            CSVLoader load = new CSVLoader();
            load.setSource(new File(input));
            Instances data = load.getDataSet();


            ArffSaver save = new ArffSaver();
            save.setInstances(data);
            save.setFile(new File(output));
            save.writeBatch();
            System.out.println("File successfully converted");
        }
        catch (Exception e) {
            System.out.println("Does not meet arff standards: " + e.getMessage());
        }



    }
    public static void main(String[] args) throws Exception{
        String input = "/Users/jason/Desktop/CSCI-657 Project 1 Files/Kids_In_Motion_Playground_Programming - _Kids_In_Motion__Playground_Programming.csv";
        String output ="/Users/jason/Desktop/CSCI-657 Project 1 Files/Kids_In_Motion_Playground_Programming - _Kids_In_Motion__Playground_Programming.arff";

        Convert(input, output);
    }

}
